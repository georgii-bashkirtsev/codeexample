<?php
//Get Settings


/* Connecting to MySQL*/
$connection = mysqli_connect("localhost","root","123")
or die("Could not connect to mysql. Fix me!?!");

/* Select Database. */
$db = mysqli_select_db($connection,"def") or die("Could not select database.");

$title = "Shelter News";


/* Selecting to show the date, topic, entry on the page.  Sorting by date with most recent at the top. */
   $sql = "SELECT date,topic,message FROM journal order by date desc";
    $sql_result = mysqli_query( $connection, $sql) or die("Query failed.");

echo "<head>
<title>$title</title>
<link href='style.css' rel='stylesheet' type='text/css'>
</head>
<BODY>




<div class='box'>

<div> S H E L T E R </div>

</div>
<div class='heading'>
<h1> Lorem Sit Amet? </h1>
</div>
";

/*setting up array and defining result values */
     while ($row = mysqli_fetch_array($sql_result)) {

$date = $row["date"];
$topic = $row["topic"];
$message = $row["message"];
$line_break_format = nl2br($message);  //Formats the entries you added using add.php to have a line break wherever you did a hard return (hit enter). Change $line_break_format to $entry below if you don't want this.

    echo "<TABLE class='news'>
   <TR>
   <TD class='date'>$date</TD>
   </TR>
   <TR>
   <TD class='topic'>$topic</TD>
   </TR>
   <TR>
    <TD class='message'>$line_break_format </TD>
    </TR>
    </TABLE>";


   }


    /* Free resultset */
    mysqli_free_result($sql_result);
    /* Closing connection */
    mysqli_close($connection);

    /* Closing page tags */

echo "</BODY></HTML>";
