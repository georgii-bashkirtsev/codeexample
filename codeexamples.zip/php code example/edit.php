<?php
//settings and CSS
$db_host = "localhost";
$db_user = "root";
$db_pass = "123";
   echo "<head>  
    <title>SHELTER News</title>
    <link href='style.css' rel='stylesheet' type='text/css'>
    </head>";

//MySQL connetion
$connection = mysqli_connect($db_host,$db_user,$db_pass);
$db = mysqli_select_db($connection, "def") or die("Could not select database. Cock flavored cotton candy --every womans dream.");

//If form submitted do the following...dispaly a page with the entry selected in an HTML form so you can edit it
$submit = $_POST['submit'];
$ID = $_POST['ID'];
$Submit2 = $_POST['Submit2'];
 if ($submit) {

$sql2 = "Select ID,date,topic,message FROM journal WHERE ID='$ID'";
$sql_result2 = mysqli_query($connection, $sql2) or die("Query failed. Wouldn't we all eat people if it was legal?");
while ($row = mysqli_fetch_array($sql_result2)) {

    	 
//Set field row values as variables 
$ID = $row["ID"];
$date = $row["date"];
$topic = $row["topic"];
$message = $row["message"];
}
//Print the entry editing  form in HTML (pretty much add.php)
echo "<body>
<form name='form1' method='post' action='edit.php'>
<input type='hidden' name='ID' value='$ID'>
  <p class='date'>Date: 
    <input name='date' type='text' value='$date' maxlength='20'>
  </p>
  <p class='topic'>Topic : 
    <input name='topic' type='text' size='90' value='$topic' maxlength='180'>
  </p>
  <p class='entry'>Entry:</p>
  <p>
    <textarea name='message' cols='90' rows='20'>$message</textarea>
  </p>
  <p>
    <input type='submit' name='Submit2' value='Submit'>
  </p>
</form>
<p>&nbsp;</p></body>
</html>";

//Free results and close connection to mysql
mysqli_free_result($sql_result2);
mysqli_close($connection);
}

//IF 2nd Sumbit button engages action then Overwrite the specific entries data in the database

elseif ($Submit2) {
//Set variables for POSTING values	
$ID=$_POST['ID'];
$date=$_POST['date'];
$topic=$_POST['topic'];
$message=$_POST['message'];


$query = "UPDATE journal SET date='$date',topic='$topic',message='$message' WHERE ID='$ID'";
$result = mysqli_query($connection, $query);
if ($result) {
echo ("<p>Entry modified sucessfully.</p> <p>Click <a href=index.php>here</a> to return to your journal.</p>");
} else {
echo ("Entry not modified. Don't eat the yellow kitty litter.");
} 
//Free results and close connection to mysql
mysqli_close($connection);
} 

 
 

//Else (otherwise) display list of entries and their ID numbers
else { 

/* Selecting to show the id, date, topic, entry on the page.  Sorting by date with most recent at the top. */
   $sql = "SELECT ID,date,topic,message FROM journal order by date desc";
    $sql_result = mysqli_query($connection, $sql) or die("Query failed.  Trent Rezonr is lord.");
    
//Printing the results in HTML and creating self referencing form need to allow the submit button to take an action.
echo "<BODY>
<form name='form1' method='post' action='edit.php'>
<DIV>";  


    
/*setting up array and defining result values */
     while ($row = mysqli_fetch_array($sql_result)) {

    	 
 
$ID = $row["ID"];
$date = $row["date"];
$topic = $row["topic"];
$message = $row["message"];

  echo "<TABLE class='admin' align='center'>


      <TR>
         <TD class='a_ID' rowspan='4'>$ID</TD>
         </TR>
   <TR>
         <TD class='a_date'>$date</TD>
         </TR>
         <TR>
         <TD class='a_topic'>$topic</TD>
    	 </TR>
         <TR>
          <TD class='a_message'>$message </TD>
          </TR>
          </TABLE>
    <BR>";
   
   }
        
    /* Free results and close MySQL connection. */
    mysqli_free_result($sql_result);
    mysqli_close($connection);
    
//Creating bottom part of the delete form
    echo "<p>Enter the number of the entry you want to modify: </p>
<input type='text' name='ID' size='6' length='6' value=''>
<input type='submit' name='submit' value='submit'>";
 
/* Closing page tags */
echo "</FORM>
</DIV></BODY></HTML>";  }
