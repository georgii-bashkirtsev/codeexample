<?php


   echo "<head>  
    <title>Shelter News</title>
    <link href='style.css' rel='stylesheet' type='text/css'>
    </head>";

//MySQL Connection
$connection = mysqli_connect("localhost","root","123");
$db = mysqli_select_db($connection, "def") or die("Could not select database.");

$ID = $_POST['ID'];
$submit = $_POST['submit'];
//IF form submitted do the following...delete the entry 
 if ($submit) {


$sql2 = "DELETE FROM journal WHERE ID='$ID'";
$sql_result2 = mysqli_query($connection, $sql2) or die("Query failed. Jesus Christ was a sand nigger.");
if ($sql_result2) {
echo ("<p>Entry removed sucessfully.</p> <p>Click <a href=index.php>here</a> to return to your journal.</p>");
} else {
echo ("Your entry was not removed. Uh, Oh. There was a problem.");
}
 /* Closing connection */
mysqli_close($connection);
} 
 

//If form submit action not inflicted display list of entries with ID numbers
else { 

/* Selecting to show the id, date, topic, entry on the page.  Sorting by date with most recent at the top. */
   $sql = "SELECT ID,date,topic,message FROM journal order by date desc";
    $sql_result = mysqli_query($connection, $sql) or die("God Damn. Query failed.");

/*Begining Page Tags */ 
 //creating self referencing form to allow the submit button to take an action.
echo "<BODY>    
<form name='form1' method='post' action='delete.php'>
<DIV>";  


    
/*setting up array and defining result values */
     while ($row = mysqli_fetch_array($sql_result)) {

    	 
 
$ID = $row["ID"];
$date = $row["date"];
$topic = $row["topic"];
$message = $row["message"];
$line_break_format = nl2br($message);  //Formats the entries you added using add.php to have a line break wherever you did a hard return (hit enter). Change $line_break_format to $entry below if you don't want this.
 
  echo "<TABLE class='admin' align='center'>


      <TR>
         <TD class='a_ID' rowspan='4'>$ID</TD>
         </TR>
   <TR>
         <TD class='a_date'>$date</TD>
         </TR>
         <TR>
         <TD class='a_topic'>$topic</TD>
    	 </TR>
         <TR>
          <TD class='a_message'>$line_break_format </TD>
          </TR>
          </TABLE>
    <BR>";
   
   }
        
    /* Free resultset */
    mysqli_free_result($sql_result);
    //Creating bottom part of the delete form
 echo "<p>Enter the number of the entry you want to remove:</p>
 <input type='text' name='ID' size='6' length='6' value=''>
 <input type='submit' name='submit' value='Delete'>";
 


 /* Closing connection */
 mysqli_close($connection);
    
/* Closing page tags */
echo "</FORM>
</DIV></BODY></HTML>";  }