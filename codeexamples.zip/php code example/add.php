 <?
 // Settings and CSS

 /* MySQL settings */
 $db_host = "localhost";
 $db_user = "root";
 $db_pass = "123";
 $database_name = "def";
 $tablename = "journal";   //If you change the default table name you have to change the table name inside of the MySQL database. Meaning...open journal.sql and replace "CREATE TABLE journal" with "CREATE TABLE your_table_name" THEN continue installation by using the sql file to create the table.

 /* Administration authorization variables. */
 $LOGIN = "user";
 $PASSWORD = "password";

 /* Site Title --Goes in all title bars, and above the journal entries on the index.php page. */
 $title = "Shelter News";
 // Time display format : Set to "we_are_superior" if you wish for the times to be displayed like (March 03, 2003 @ 12:50 pm.) in index.php.  Otherwise set to "fuckin_americans" to get universal time format (2003-03-03 12:50). Times on the ADD and EDIT pages will ALWAYS be universal. This just defines index.php.

echo "<head>  
    <title>$title</title>
    <link href='style.css' rel='stylesheet' type='text/css'>
    </head>";

//MySQL Connection  
$connection = MySQLi_connect($db_host,$db_user,$db_pass)
or die("Could not connect to mysql. This always happens to me..."); 
MySQLi_select_db($connection, $database_name) or die("Could not select database. Oh well, I give up.");


     //IF form is submitted add to database.
$Submit = $_POST['Submit'];
$date = $_POST['date'];
$topic = $_POST['topic'];
$message = $_POST['message'];
 if ($Submit) {


//Assign form NAMES to databse fileds.  NULL is for autoincrement.
$query = "INSERT INTO journal (date, Topic, message) VALUES ('$date','$topic','$message')";
$result = mysqli_query($connection, $query);
if ($result) {
echo ("<p>Message added sucessfully.</p> <p>Click <a href=index.php>here</a> to return to your journal.</p>");
} else {
echo ("Message not added.  There was a problem somewhere, fix it.");
} 

    /* Closing connection */
    mysqli_close($connection);


} 


else {
//ELSE, IF form is has not inflicted SUBMIT action...display the ADD entry form.
//setup date for MySQL NOW insert
date_default_timezone_set('Europe/Helsinki');
$date = date ("Y-m-d H:i:s");
echo "<body>
<form name='form1' method='post' action='add.php'>

  <p class='date'>Date: 
    <input name='date' type='text' value='$date' maxlength='20'>
  </p>
  <p class='topic'>Topic : 
    <input name='topic' type='text' size='90' maxlength='180'>
  </p>
  <p class='entry'>Entry:</p>
  <p>
    <textarea name='message' cols='90' rows='20'></textarea>
  </p>
  <p>
    <input type='submit' name='Submit' value='Submit'>
  </p>
</form>
<p>&nbsp;</p></body>
</html>";
}
