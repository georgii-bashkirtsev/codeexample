package com.main.shelter;

//JUST AN APPLICATION STARTING MAIN PART OF THE PROJECT

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class fbdApplication {

    public static void main(String[] args) {
        SpringApplication.run(fbdApplication.class, args);
    }

}
//ALL THE NECESSARY PAGES ARE NAMED SIMPLY SO IT WOULD BE CLEAR TO UNDERSTAND WHAT DO THEY STAND FOR