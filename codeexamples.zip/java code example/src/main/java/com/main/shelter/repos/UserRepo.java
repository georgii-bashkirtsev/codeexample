package com.main.shelter.repos;

//REPOSITORY WORKING WITH USER INFO

import com.main.shelter.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepo extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
