package com.main.shelter.domain;

import javax.persistence.*;

//UNUSED CLASS MADE FOR FUTURE DIALOG WITH PSYCHOTHERAPIST

@Entity // This tells Hibernate to make a table out of this class
public class Message {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Integer id;

    private String text;
    private String nickname;

    public Message() {

    }

    public Message(String text, String nickname) {
        this.text = text;
        this.nickname = nickname;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
}
