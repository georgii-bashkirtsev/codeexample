package com.main.shelter.repos;

//UNUSED REPOSITORY MADE FOR WORKING WITH FUTURE DIALOG WITH PSYCHOTHERAPIST

import com.main.shelter.domain.Message;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface MessageRepo extends CrudRepository<Message, Long>{

    List<Message> findByNickname(String tag);
}
