//JUST A SIMPLE CLASS FOR USER ROLES, WILL BE UPDATED IN THE FUTURE
package com.main.shelter.domain;

public enum Role {
    USER;
}
