package com.main.shelter.controller;

//HERE'S THE MAIN CONTROLLER GIVING MAPPING TO ALL THE EXISTING PAGES EXCEPT REG

import com.main.shelter.domain.Message;
import com.main.shelter.repos.MessageRepo;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Controller
public class MainController {

    @Autowired //UNUSED, WIRES MESSAGES WITH REPO FOR THE FUTURE dialog WITH PSYCHOTHERAPIST
    private MessageRepo messageRepo;

    @GetMapping("/main")  //RETURNS MAIN PAGE
    public String greeting() {
        return "main";
    }

    @GetMapping //RETURNS STARTING PAGE
    public String starter() {
        return "projStart";
    }

    @GetMapping("/myDb") //UNUSED, MADE FOR THE FUTURE DIALOG WITH PSYCHOTHERAPIST
    public String messages(Map<String, Object> model) {
        Iterable<Message> messages = messageRepo.findAll();


        model.put("messages", messages);
        return "messages";
    }

    @PostMapping("/myDb") //UNUSED, MADE FOR THE FUTURE DIALOG WITH PSYCHOTHERAPIST
    public String add(@RequestParam String text, @RequestParam String nickname, Map<String, Object> model) {
        Message message = new Message(text, nickname);

        messageRepo.save(message);

        Iterable<Message> messages = messageRepo.findAll();

        model.put("messages", messages);

        return "messages";
    }

    @PostMapping("filter") //UNUSED, MADE FOR THE FUTURE DIALOG WITH PSYCHOTHERAPIST
    public String filter(@RequestParam String filter, Map<String, Object> model) {
        Iterable<Message> messages;

        if (filter != null && !filter.isEmpty()) {
            messages = messageRepo.findByNickname(filter);
        } else {
            messages = messageRepo.findAll();
        }

        model.put("messages", messages);

        return "messages";
    }

    @GetMapping("/login") // RETURNS LOGIN PAGE
    public String login() {

        return "login";

    }


//REGISTRATION IS MAPPED IN THE RegistrationController
    //ALL THE SETTINGS FOR THE SPRINGBOOT ARE WRITTEN IN application.properties
    //THE PAGES IN THIS PROJECT ARE WORKING ON THE PORT:8090

}