package com.main.shelter.controller;

//THIS CLASS CONTROLS THE PROCESS OF THE REGISTRATION
//THERE ARE SOME INPUTS ON THE REG PAGE THAT SRE NOT FUNCTIONING YET. THEY DON'T SEND DATA TO DB, BUT ARE MADE FOR FUTURE PURPOSES.

import com.main.shelter.domain.Role;
import com.main.shelter.domain.User;
import com.main.shelter.repos.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Collections;
import java.util.Map;


@Controller
public class RegistrationController {
    @Autowired
    private UserRepo userRepo;

    @GetMapping("/reg0") //RETURNS REG PAGE
    public String registration() {
        return "registration";
    }
    @PostMapping("/reg0")
    public String addUser(User user, Map<String, Object> model){
       User userFromDb = userRepo.findByUsername(user.getUsername());

       if (userFromDb != null) {
           model.put("message", "User exists!");
           return "registration";
       }

       user.setActive(true);
       user.setRoles(Collections.singleton(Role.USER));
       userRepo.save(user);

        return "redirect:/login";
    }
}
